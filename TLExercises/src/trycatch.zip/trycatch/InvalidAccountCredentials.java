package trycatch;

public class InvalidAccountCredentials extends Exception {

	public InvalidAccountCredentials(String string) {
		// TODO Auto-generated constructor stub
	}

}
