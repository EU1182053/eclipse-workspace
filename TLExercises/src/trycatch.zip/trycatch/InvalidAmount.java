package trycatch;

public class InvalidAmount extends Exception {

}
