package trycatch;

public class FourDigitPin extends Exception {

	public FourDigitPin(String string) {
		// TODO Auto-generated constructor stub
	}

}
