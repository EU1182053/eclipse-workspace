package com.servlets;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.model.userImpl;
import com.pojo.User;

/**
 * Servlet implementation class MyUserServlet
 */
@WebServlet("/MyUserServlet")
public class MyUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyUserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Request Received");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String useraction = request.getParameter("heyy");
		System.out.println(useraction);
		if (useraction.equalsIgnoreCase("Registeraction")) {
		System.out.println("Post");
		String name = request.getParameter("myName");
		int age = Integer.parseInt(request.getParameter("myAge"));
		double contactNumber = Double.parseDouble(request.getParameter("contact"));
		String email = request.getParameter("email");
		String uname = request.getParameter("uname");
		String password = request.getParameter("pass");
		String gender = request.getParameter("gender");
		String location = request.getParameter("loc");
		String course[] = request.getParameterValues("course");
		List<String> courselist = Arrays.asList(course);
		
		User obj1 = new User();
		obj1.setAge(age);
		obj1.setName(name);
		obj1.setContact(contactNumber);
		obj1.setEmail(email);
		obj1.setUname(uname);
		obj1.setPassword(password);
		obj1.setGender(gender);
		obj1.setLocation(location);
		obj1.setCourselist(courselist);
		
		userImpl obj2 = new userImpl();
		obj2.test(obj1);
		}
		else {
			String username = request.getParameter("unamee");
			String password = request.getParameter("passs");
			userImpl obj2 = new userImpl();
			boolean user = obj2.logintest(username, password);
			
			if (user) {
				response.sendRedirect("Success.html");
				
			}else {
				response.sendRedirect("Error.html");
				
			}
			}
			
		}
		
			
	}
		


