package com.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.protocol.Resultset;
import com.pojo.User;

public class userImpl {
	
	public boolean test(User user) {
		
	
		try {
		    Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		Connection connection=null;
		Statement sc = null;
		String url="jdbc:mysql://localhost:3306/user";
		String username="root";
		String password="Akshat@11";
		try {
			connection=DriverManager.getConnection(url,username,password);
			String sql1 = "Insert into users values (?,?,?,?,?,?,?,?)";
			PreparedStatement pstmt = connection.prepareCall(sql1);
			pstmt.setString(1, user.getName());
			pstmt.setLong(2, user.getAge());
			pstmt.setLong(3, (long) user.getContact());
			pstmt.setString(4, user.getEmail());
			pstmt.setString(5, user.getUname());
			pstmt.setString(6, user.getPassword());
			pstmt.setString(7, user.getGender());
			pstmt.setString(8, user.getLocation());
			int no = pstmt.executeUpdate();
			if (no>=1) {
				System.out.println("Done");
			}else {
				System.out.println("Not");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
				
	}
	
	
	
	
	public boolean logintest(String username , String password) {
		
		boolean check = false;
		try {
		    Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Connection connection=null;
	
		String url="jdbc:mysql://localhost:3306/user";
		
		try {
			connection=DriverManager.getConnection(url,"root","Akshat@11");
			String sql1 = "select * from users where username = ?  and password = ?";
			PreparedStatement pstmt = connection.prepareStatement(sql1);
			pstmt.setString(1,  username);
			pstmt.setString(2,  password);
			
			ResultSet rs = pstmt.executeQuery();
			
			if(rs.next()) {
				System.out.println("User Exist");
				check=true;
			}else {
				System.out.println("User Dont Exist or Wrong Password Or Username Entered");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return check;
		
	}
}
